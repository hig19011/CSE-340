<?php $pageTitle = 'Content Title';?>

<h1>Content Title Here</h1>