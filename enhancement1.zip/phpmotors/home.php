<?php
  //setup page
  include('modules/template-init.php');
  init('Home', 'content/home-body.php','modules/template-core.php');  
?>