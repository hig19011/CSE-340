<?php 
    //setup page
    include('modules/template-init.php');
    init('Content Title', 'content/default.php','modules/template-core.php');    
?>


