<?php 
    //setup page
    include_once('modules/template-init.php');
    init('Content Title', 'view/default.php','modules/template-core.php');    
?>


