<div>
  <a href="home.php" title="PHP Motors Home page"><img src="images/site/logo.png" alt="php motors logo"></a>
  <a href="#" title="View My Account">My Account</a>
</div>