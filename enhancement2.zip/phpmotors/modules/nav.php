<div>
  <ul>
    <li><a href="home.php" title="Go to the Home page">Home</a></li>
    <li class="selected" title="Browse classic cars"><a href="#">Classic</a></li>
    <li><a href="#" title="Browse sports cars">Sports</a></li>
    <li><a href="#" title="Browse SUVs">SUV</a></li>
    <li><a href="#" title="Browse trucks">Trucks</a></li>
    <li><a href="#" title="Browse used vehicles">Used</a></li>
  </ul>
</div>