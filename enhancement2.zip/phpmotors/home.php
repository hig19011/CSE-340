<?php
  //setup page
  include_once('modules/template-init.php');
  init('Home', 'view/home-body.php','modules/template-core.php');  
?>