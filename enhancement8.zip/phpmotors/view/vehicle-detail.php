<?php
  displayGlobalMessage();

  echo $vehicleDisplay;
?>

