<div>
  <a href="/phpmotors" title="PHP Motors Home page"><img src="images/site/logo.png" alt="php motors logo"></a>
  <a href="/phpmotors/accounts/index.php?action=login-page" title="View My Account">My Account</a>
</div>