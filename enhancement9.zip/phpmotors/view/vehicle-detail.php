<?php
  displayGlobalMessage();

  echo "<section class='details-container'>";
  echo $vehicleDisplay;
  echo "<h3>More Images</h3>";
  echo $thumbnailsDisplay;
  echo "</section>";
?>

