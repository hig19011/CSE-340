<h1><?php echo $classificationName; ?> vehicles</h1>
<?php displayGlobalMessage(); ?>
<?php if(isset($vehicleDisplay)){
  echo $vehicleDisplay;  
} ?>